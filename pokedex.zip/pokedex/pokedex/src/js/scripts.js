let pokemonRepository = function(){
    let o=[],e="https://pokeapi.co/api/v2/pokemon/?limit=5000";
    function t(e){
        "object"==typeof e &&"name" in e &&"detailsUrl"in e && o.push(e)}
    function l(o){
        pokemonRepository.loadDetails(o).then(function(){
          console.log(o);
            d(o)
          }
          )
    }
    function d(o){
        $(".modal-header");
        let e=$(".modal-body"),t=$(".modal-title");
        $("#pokedexModal").modal("show"), t.empty() , e.empty();        
        let l=$("<h1>"+o.name+"</h1>"), d=$('<img class="modal-img" alt="pokemon image">');
        d.attr("src",o.imageUrl); 
        let a=$("<p>Height: "+o.height+"</p>"), n=$("<p>Weight: "+o.weight+"</p>"), r=$("<p>Types: "+o.types+"</p>"),s=$("<p>Abilities: "+o.abilities+"</p>");
        t.append(l), e.append(d), e.append(a),e.append(n),e.append(r),e.append(s);
        
        e.append("<div><canvas id='grafico'></canvas></div>");
        
        const ctx = document.getElementById('grafico');

        new Chart(ctx, {
          type: 'bar',
          data: {
            labels: ['Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange'],
            datasets: [{
              label: '# of Votes',
              data: [12, 19, 3, 5, 2, 3],
              borderWidth: 1
            }]
          },
          options: {
            scales: {
              y: {
                beginAtZero: true
              }
            }
          }
        });
      
            
           
            
           

        

        
    }
    return{
        add:t,getAll:function(){return o},addListItem:function(o){pokemonRepository.loadDetails(o).then(function(){let e=$(".pokemon-list"),t=$('<li id="list">'),d=$("<button>"+o.name+"</button>"),a=$('<img class="button-icon" alt="button image" />');
        
        a.attr("src",o.imageUrl),d.addClass("btn btn-light btn-lg"),d.append(a),t.append(d),e.append(t),d.on("click",function(e){l(o)})})},loadList:function(){return $.ajax(e).then(function(o){o.results.forEach(function(o){t({name:o.name,detailsUrl:o.url})})}).catch(function(o){console.error(o)})},loadDetails:function(o){let e=o.detailsUrl;
            
            return $.ajax(e).then(function(e){
              o.imageUrl=e.sprites.other.dream_world.front_default,
              o.height=e.height,
              o.weight=e.weight,
              o.types=[], o.stats= []; for(let t=0; t< e.stats; t++) o.stats.push(e.stats[t].base_stat); for(let t=0;t<e.types.length; t++)o.types.push(e.types[t].type.name); 
                o.types[0].includes("grass")?$(".modal-body, .modal-header, .modal-footer").css("background-color","rgb(0,211,0,0.75)"):o.types[0].includes("fire")?$(".modal-body, .modal-header, .modal-footer").css("background-color","rgb(255,0,0,0.75)"):o.types[0].includes("electric")?$(".modal-body, .modal-header, .modal-footer").css("background-color","rgb(243,241,0,0.75)"):o.types[0].includes("poison")?$(".modal-body, .modal-header, .modal-footer").css("background-color","rgb(137,2,211,0.75)"):o.types[0].includes("flying")?$(".modal-body, .modal-header, .modal-footer").css("background-color","rgb(2,155,255,0.75)"):o.types[0].includes("water")?$(".modal-body, .modal-header, .modal-footer").css("background-color","rgb(3,52,255,0.75)"):o.types[0].includes("normal")?$(".modal-body, .modal-header, .modal-footer").css("background-color","rgb(255,151,0,0.75)"):o.types[0].includes("fighting")?$(".modal-body, .modal-header, .modal-footer").css("background-color","rgb(242,0,137,0.75)"):o.types[0].includes("ground")?$(".modal-body, .modal-header, .modal-footer").css("background-color","rgb(179,87,0,0.75)"):o.types[0].includes("rock")?$(".modal-body, .modal-header, .modal-footer").css("background-color","rgb(161,149,137,0.75)"):o.types[0].includes("bug")?$(".modal-body, .modal-header, .modal-footer").css("background-color","rgb(163,88,142,0.75)"):o.types[0].includes("ghost")?$(".modal-body, .modal-header, .modal-footer").css("background-color","rgb(255,255,255,0.75)"):o.types[0].includes("steel")?$(".modal-body, .modal-header, .modal-footer").css("background-color","rgb(132,132,132,0.75)"):o.types[0].includes("psychic")?$(".modal-body, .modal-header, .modal-footer").css("background-color","rgb(235,95,80,0.75)"):o.types[0].includes("ice")?$(".modal-body, .modal-header, .modal-footer").css("background-color","rgb(19,131,255,0.75)"):o.types[0].includes("dragon")?$(".modal-body, .modal-header, .modal-footer").css("background-color","rgb(250,103,44,0.75)"):o.types[0].includes("dark")?$(".modal-body, .modal-header, .modal-footer").css("background-color","rgb(50,50,50,0.75)"):o.types[0].includes("fairy")&&$(".modal-body, .modal-header, .modal-footer").css("background-color","rgb(229,131,229,0.75)"),o.abilities=[];for(let t=0;t<e.abilities.length;t++)o.abilities.push(e.abilities[t].ability.name)}).catch(function(o){console.error(o)})},showDetails:l,showModal:d}}();
                
                function myFunction(){let o,e,t,l,d,a,n;for(e=(o=document.getElementById("myInput")).value.toUpperCase(),l=(t=document.getElementById("myUL")).querySelectorAll("#list"),a=0;a<l.length;a++)d=l[a].getElementsByTagName("button")[0],console.log(d.innerText),(n=d.textContent||d.innerText).toUpperCase().indexOf(e)>-1?l[a].style.display="":l[a].style.display="none"}pokemonRepository.loadList().then(function(){pokemonRepository.getAll().forEach(function(o){pokemonRepository.addListItem(o)})});
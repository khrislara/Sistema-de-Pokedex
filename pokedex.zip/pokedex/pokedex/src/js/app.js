var NameLabel = [], HeightData = [], WeightData = [], TypesData = [], AbilitiesData = []

async function PokemonChart() {
  await getPokemonData()

  const ctx = document.getElementById('myChart').getContext('2d');

  const Chart = new Chart(ctx, {
    // El tipo de gráfico que queremos crear
    type: 'bar',

    // Los datos para nuestro conjunto de datos
    data: {
      labels: NameLabel,
      datasets: [{
        label: 'Height ',
        backgroundColor: 'blue',
        borderColor: 'rgb(255, 99, 132)',
        data: HeightData
      },
      {
        label: 'Weight',
        backgroundColor: 'ween',
        borderColor: 'rgb(255, 99, 132)',
        data: WeightData
      },
      {
        label: 'Types',
        backgroundColor: 'pink',
        borderColor: 'rgb(255, 99, 132)',
        data: TypesData
      },
      {
        label: 'Abilities',
        backgroundColor: 'red',
        borderColor: 'rgb(255, 99, 132)',
        data: AbilitiesData
      }
      ]
    },

    // Las opciones de configuración van aquí
    options: {
      tooltips: {
        mode: 'index'
      }
    }
  })
}

PokemonChart()


//Obtener datos de la API

async function getPokemonData() {
  const apiUrl = "https://pokeapi.co/api/v2/pokemon/?limit=5000"

  const response = await fetch(apiUrl)
  const barChatData = await response.json()

  const Height = barChatData.data.map((x) => x.Height)
  console.log(Height)
  const Weight = barChatData.data.map((x) => x.Weight)
  console.log(Weight)
  const Types = barChatData.data.map((x) => x.Types)
  const Abilities = barChatData.data.map((x) => x.Abilities)
  const name = barChatData.data.map((x) => x.Name)

  HeightData = Height
  WeightData = Weight
  TypesData = Types
  AbilitiesData = Abilities
  NameLabel = name
}